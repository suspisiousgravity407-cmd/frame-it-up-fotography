import InstagramIcon from "./icons/InstagramIcon";
import { business, instagramTiles } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";

export default function Instagram() {
  const ref = useReveal();

  return (
    <section className="bg-ink py-24 md:py-32 border-t border-ink-line">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="flex flex-col items-center text-center mb-12 md:mb-14">
          <InstagramIcon size={26} className="text-lime mb-4" strokeWidth={1.5} />
          <p className="font-mono-label text-xs text-lime mb-3">
            {business.instagramHandle}
          </p>
          <h2 className="font-display text-3xl md:text-4xl text-cream-text max-w-lg text-balance">
            More frames, more feedback — on Instagram.
          </h2>
          <a
            href={business.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-7 inline-flex items-center gap-2 px-7 py-3 border border-lime text-lime text-sm font-semibold tracking-wide hover:bg-lime hover:text-ink transition-colors duration-300"
          >
            Follow Us on Instagram
          </a>
        </div>

        <div
          ref={ref}
          className="grid grid-cols-3 md:grid-cols-6 gap-2 md:gap-3"
        >
          {instagramTiles.map((img, i) => (
            <a
              key={img}
              href={business.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="reveal group relative aspect-square overflow-hidden bg-ink-soft"
              data-reveal-delay={i * 60}
              aria-label="View on Instagram"
            >
              <img
                src={resolveImage(img)}
                alt=""
                loading="lazy"
                width={300}
                height={300}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-ink/0 group-hover:bg-ink/40 transition-colors duration-300 flex items-center justify-center">
                <InstagramIcon
                  size={20}
                  className="text-cream-text opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                />
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
