import { featuredWork } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";

export default function FeaturedWork() {
  const ref = useReveal();

  return (
    <section className="bg-paper text-ink py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <p className="font-mono-label text-xs text-maroon mb-4">
          Featured Work
        </p>

        <div ref={ref} className="space-y-20 md:space-y-28">
          {featuredWork.map((work, i) => (
            <article
              key={work.id}
              className={`reveal grid md:grid-cols-2 gap-8 md:gap-16 items-center ${
                i % 2 === 1 ? "md:[direction:rtl]" : ""
              }`}
            >
              <div className={i % 2 === 1 ? "md:[direction:ltr]" : ""}>
                <img
                  src={resolveImage(work.image)}
                  alt={work.title}
                  loading="lazy"
                  width={900}
                  height={720}
                  className="w-full aspect-[5/4] object-cover"
                />
              </div>
              <div className={i % 2 === 1 ? "md:[direction:ltr]" : ""}>
                <h3 className="font-display text-3xl md:text-4xl leading-tight text-balance mb-4">
                  {work.title}
                </h3>
                <p className="text-ink/70 text-base md:text-lg leading-relaxed max-w-md">
                  {work.description}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
