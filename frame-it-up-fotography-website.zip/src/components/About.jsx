import { MapPin } from "lucide-react";
import { business } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";

const aboutImage = resolveImage("gallery/bridal-frame.jpg");

export default function About() {
  const ref = useReveal();

  return (
    <section
      id="about"
      ref={ref}
      className="relative bg-paper text-ink py-24 md:py-32 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-5 md:px-8 grid md:grid-cols-2 gap-14 md:gap-20 items-center">
        <div className="reveal order-2 md:order-1">
          <p className="font-mono-label text-xs text-maroon mb-4">
            About the Studio
          </p>
          <h2 className="font-display text-4xl md:text-5xl leading-[1.1] text-balance mb-6">
            Every frame starts with a photograph worth keeping.
          </h2>
          <div className="space-y-4 text-ink/75 text-base md:text-[1.05rem] leading-relaxed max-w-lg font-body">
            <p>
              Frame It Up Fotography is a {business.locationShort} studio
              built around one idea: a photograph is only half the job. The
              other half is what happens to it after the shoot — printed,
              composed, framed and delivered as something you'll actually
              keep.
            </p>
            <p>
              We shoot weddings and pre-wedding stories on location, and we
              build the keepsakes ourselves — farewell batch collages,
              portrait frames, personalised money banks, cushions and
              keychains — for individuals, couples, and graduating classes of
              60 or more.
            </p>
            <p className="text-sm text-ink/50 border-l-2 border-maroon/40 pl-4 italic">
              [Photographer / founder bio — add a short introduction here
              once you share it, so this reads as a personal note rather than
              a studio description.]
            </p>
          </div>

          <div className="mt-8 flex items-center gap-2.5 text-sm font-mono-label text-ink/70">
            <MapPin size={16} className="text-maroon shrink-0" />
            {business.location}
          </div>
        </div>

        <div className="reveal order-1 md:order-2 relative">
          <div className="relative mx-auto max-w-sm md:max-w-none frame-border">
            <img
              src={aboutImage}
              alt="Framed bridal portrait held up against a brick wall backdrop"
              className="w-full aspect-[4/5] object-cover"
              loading="lazy"
              width={720}
              height={900}
            />
          </div>
          <div className="absolute -bottom-6 -left-6 md:-left-10 bg-ink text-lime spec-tag !text-[0.7rem] !px-4 !py-2 hidden xs:inline-flex">
            Framed &amp; delivered
          </div>
        </div>
      </div>
    </section>
  );
}
