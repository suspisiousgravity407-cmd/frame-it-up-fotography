import { Phone, MapPin, Mail, MessageCircle } from "lucide-react";
import InstagramIcon from "./icons/InstagramIcon";
import { business } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";

const bgImage = resolveImage("products/combo-offer.jpg");

export default function Contact() {
  const ref = useReveal();

  return (
    <section id="contact" className="relative bg-paper text-ink py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={ref} className="grid lg:grid-cols-[1.1fr_0.9fr] gap-14 lg:gap-20">
          <div className="reveal">
            <p className="font-mono-label text-xs text-maroon mb-4">
              Get In Touch
            </p>
            <h2 className="font-display text-4xl md:text-5xl leading-[1.1] text-balance mb-6">
              Let&rsquo;s work together.
            </h2>
            <p className="text-ink/70 text-base md:text-lg max-w-md leading-relaxed mb-10">
              Booking a shoot, ordering a farewell batch frame, or just have a
              question about sizes and pricing — reach out directly.
            </p>

            <ul className="space-y-5">
              <li>
                <a
                  href={business.phoneHref}
                  className="group flex items-center gap-4"
                >
                  <span className="w-11 h-11 flex items-center justify-center border border-ink/15 group-hover:border-maroon group-hover:text-maroon transition-colors shrink-0">
                    <Phone size={18} />
                  </span>
                  <span>
                    <span className="block text-xs font-mono-label text-ink/45">
                      Call or WhatsApp
                    </span>
                    <span className="block text-lg font-display">
                      {business.phone}
                    </span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href={business.mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-4"
                >
                  <span className="w-11 h-11 flex items-center justify-center border border-ink/15 group-hover:border-maroon group-hover:text-maroon transition-colors shrink-0">
                    <MapPin size={18} />
                  </span>
                  <span>
                    <span className="block text-xs font-mono-label text-ink/45">
                      Studio Location
                    </span>
                    <span className="block text-lg font-display">
                      {business.location}
                    </span>
                  </span>
                </a>
              </li>
              <li>
                <a
                  href={business.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center gap-4"
                >
                  <span className="w-11 h-11 flex items-center justify-center border border-ink/15 group-hover:border-maroon group-hover:text-maroon transition-colors shrink-0">
                    <InstagramIcon size={18} />
                  </span>
                  <span>
                    <span className="block text-xs font-mono-label text-ink/45">
                      Instagram
                    </span>
                    <span className="block text-lg font-display">
                      {business.instagramHandle}
                    </span>
                  </span>
                </a>
              </li>
              {business.email && (
                <li>
                  <a
                    href={`mailto:${business.email}`}
                    className="group flex items-center gap-4"
                  >
                    <span className="w-11 h-11 flex items-center justify-center border border-ink/15 group-hover:border-maroon group-hover:text-maroon transition-colors shrink-0">
                      <Mail size={18} />
                    </span>
                    <span>
                      <span className="block text-xs font-mono-label text-ink/45">
                        Email
                      </span>
                      <span className="block text-lg font-display">
                        {business.email}
                      </span>
                    </span>
                  </a>
                </li>
              )}
            </ul>

            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={business.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-ink text-cream-text text-sm font-semibold tracking-wide hover:bg-maroon transition-colors duration-300"
              >
                <MessageCircle size={16} /> Message on WhatsApp
              </a>
              <a
                href={business.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3.5 border border-ink/25 text-sm font-semibold tracking-wide hover:border-maroon hover:text-maroon transition-colors duration-300"
              >
                Get Directions
              </a>
            </div>
          </div>

          <div className="reveal relative min-h-[320px] lg:min-h-full">
            <div className="frame-border h-full">
              <img
                src={bgImage}
                alt="Sample of framed portraits available from Frame It Up Fotography"
                className="w-full h-full object-cover min-h-[320px]"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
