import { useEffect, useState } from "react";
import { ArrowDown } from "lucide-react";
import { business } from "../data/siteData";
import { resolveImage } from "../utils/images";

const heroImage = resolveImage("hero/wedding-couple.jpg");

export default function Hero() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(t);
  }, []);

  const scrollTo = (e, href) => {
    e.preventDefault();
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-[100svh] flex items-end overflow-hidden bg-ink"
    >
      {/* Background photograph */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Bride and groom walking hand in hand toward a temple entrance, Coimbatore"
          className={`w-full h-full object-cover object-[45%_20%] transition-transform duration-[2.5s] ease-out ${
            mounted ? "scale-100" : "scale-110"
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-ink/10" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink/60 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-5 md:px-8 pb-20 md:pb-28 pt-40">
        <p
          className={`spec-tag mb-5 transition-all duration-700 delay-100 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"
          }`}
        >
          {business.locationShort} · Est. Studio
        </p>

        <h1
          className={`font-display text-[2.5rem] leading-[1.05] xs:text-5xl md:text-7xl lg:text-[5.5rem] text-cream-text max-w-4xl text-balance transition-all duration-[900ms] delay-150 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          We Don&rsquo;t Just Capture{" "}
          <span className="italic text-lime">Moments.</span>
          <br />
          We Frame Them.
        </h1>

        <p
          className={`mt-6 max-w-xl text-cream-text/80 text-base md:text-lg font-body transition-all duration-700 delay-300 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          {business.subTagline}
        </p>

        <div
          className={`mt-10 flex flex-wrap items-center gap-4 transition-all duration-700 delay-500 ${
            mounted ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"
          }`}
        >
          <a
            href="#portfolio"
            onClick={(e) => scrollTo(e, "#portfolio")}
            className="px-7 py-3.5 bg-lime text-ink text-sm font-semibold tracking-wide hover:bg-cream-text transition-colors duration-300"
          >
            View Our Work
          </a>
          <a
            href="#contact"
            onClick={(e) => scrollTo(e, "#contact")}
            className="px-7 py-3.5 border border-cream-text/40 text-cream-text text-sm font-semibold tracking-wide hover:border-lime hover:text-lime transition-colors duration-300"
          >
            Contact Us
          </a>
        </div>
      </div>

      <a
        href="#about"
        onClick={(e) => scrollTo(e, "#about")}
        aria-label="Scroll to About section"
        className="hidden md:flex absolute bottom-8 right-8 z-10 items-center gap-2 text-cream-text/60 hover:text-lime transition-colors text-xs font-mono-label"
      >
        Scroll
        <ArrowDown size={14} className="animate-bounce" />
      </a>
    </section>
  );
}
