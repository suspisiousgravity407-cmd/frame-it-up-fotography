import { Camera, Users, Truck, Heart } from "lucide-react";
import { whyChooseUs } from "../data/siteData";
import { useReveal } from "../hooks/useReveal";

const icons = [Camera, Users, Truck, Heart];

export default function WhyChooseUs() {
  const ref = useReveal();

  return (
    <section className="bg-ink py-24 md:py-32 border-t border-ink-line">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <header className="max-w-2xl mb-14 md:mb-16">
          <p className="font-mono-label text-xs text-lime mb-4">
            Why Frame It Up
          </p>
          <h2 className="font-display text-4xl md:text-5xl leading-[1.1] text-cream-text text-balance">
            Built around the keepsake, not just the shoot.
          </h2>
        </header>

        <div
          ref={ref}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12"
        >
          {whyChooseUs.map((item, i) => {
            const Icon = icons[i % icons.length];
            return (
              <div
                key={item.id}
                className="reveal"
                data-reveal-delay={i * 100}
              >
                <div className="w-11 h-11 flex items-center justify-center border border-lime/40 text-lime mb-5">
                  <Icon size={20} strokeWidth={1.6} />
                </div>
                <h3 className="font-display text-xl text-cream-text mb-2.5">
                  {item.title}
                </h3>
                <p className="text-sm text-mute leading-relaxed">
                  {item.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
