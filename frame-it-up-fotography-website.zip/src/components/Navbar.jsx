import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import { business, nav } from "../data/siteData";
import { resolveImage } from "../utils/images";

const logo = resolveImage("logo/logo-full.png");

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#home");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const sections = nav
      .map((n) => document.querySelector(n.href))
      .filter(Boolean);
    if (sections.length === 0) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActive(`#${entry.target.id}`);
          }
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  const handleNavClick = (e, href) => {
    e.preventDefault();
    setOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled
          ? "py-2 bg-ink/90 backdrop-blur-md border-b border-ink-line shadow-[0_10px_30px_-15px_rgba(0,0,0,0.6)]"
          : "py-4 md:py-6 bg-gradient-to-b from-ink/70 to-transparent"
      }`}
    >
      <nav
        aria-label="Primary"
        className="max-w-7xl mx-auto px-5 md:px-8 flex items-center justify-between"
      >
        <a
          href="#home"
          onClick={(e) => handleNavClick(e, "#home")}
          className="flex items-center gap-2.5 shrink-0"
          aria-label={`${business.name} — home`}
        >
          <img
            src={logo}
            alt={`${business.name} logo`}
            className={`w-auto transition-all duration-500 rounded-sm ${
              scrolled ? "h-9" : "h-11 md:h-12"
            }`}
          />
          <span className="hidden sm:flex flex-col leading-none">
            <span className="font-display font-semibold tracking-wide text-cream-text text-sm md:text-base">
              Frame It Up
            </span>
            <span className="font-mono-label text-[0.55rem] text-lime">
              FOTOGRAPHY
            </span>
          </span>
        </a>

        <ul className="hidden md:flex items-center gap-8 font-body text-sm">
          {nav.map((item) => (
            <li key={item.href}>
              <a
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`relative py-1 transition-colors duration-300 ${
                  active === item.href
                    ? "text-lime"
                    : "text-cream-text/85 hover:text-lime"
                }`}
              >
                {item.label}
                <span
                  className={`absolute -bottom-0.5 left-0 h-px bg-lime transition-all duration-300 ${
                    active === item.href ? "w-full" : "w-0"
                  }`}
                />
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden md:flex items-center gap-3">
          <a
            href={business.phoneHref}
            className="inline-flex items-center gap-2 text-sm text-cream-text/90 hover:text-lime transition-colors"
          >
            <Phone size={15} strokeWidth={2} />
            <span className="font-mono-label text-xs">{business.phone}</span>
          </a>
          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, "#contact")}
            className="ml-2 px-5 py-2.5 bg-lime text-ink text-sm font-semibold tracking-wide hover:bg-cream-text transition-colors duration-300"
          >
            Book a Session
          </a>
        </div>

        <button
          type="button"
          className="md:hidden text-cream-text p-2 -mr-2"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        className={`md:hidden overflow-hidden transition-[max-height,opacity] duration-400 ease-out ${
          open ? "max-h-[26rem] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <ul className="px-6 pt-4 pb-6 flex flex-col gap-1 bg-ink/95 backdrop-blur-md border-t border-ink-line mt-4">
          {nav.map((item) => (
            <li key={item.href}>
              <a
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`block py-3 text-base border-b border-ink-line/70 ${
                  active === item.href ? "text-lime" : "text-cream-text/90"
                }`}
              >
                {item.label}
              </a>
            </li>
          ))}
          <li className="pt-4 flex flex-col gap-3">
            <a
              href={business.phoneHref}
              className="inline-flex items-center gap-2 text-cream-text/90"
            >
              <Phone size={16} /> {business.phone}
            </a>
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, "#contact")}
              className="text-center px-5 py-3 bg-lime text-ink text-sm font-semibold tracking-wide"
            >
              Book a Session
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}
