import { useEffect, useCallback } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { resolveImage } from "../utils/images";

export default function Lightbox({ items, index, onClose, onNavigate }) {
  const item = items[index];

  const handleKey = useCallback(
    (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onNavigate((index + 1) % items.length);
      if (e.key === "ArrowLeft")
        onNavigate((index - 1 + items.length) % items.length);
    },
    [index, items.length, onClose, onNavigate]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [handleKey]);

  if (!item) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${item.caption} — image viewer`}
      className="fixed inset-0 z-[100] bg-ink/97 backdrop-blur-sm flex flex-col animate-[fadeIn_0.25s_ease-out]"
      onClick={onClose}
    >
      <div className="flex items-center justify-between px-5 md:px-8 py-5 shrink-0">
        <span className="font-mono-label text-xs text-lime">
          {item.category}
        </span>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close image viewer"
          className="text-cream-text/80 hover:text-lime transition-colors p-2 -m-2"
        >
          <X size={26} />
        </button>
      </div>

      <div
        className="flex-1 flex items-center justify-center px-4 md:px-20 min-h-0"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={() => onNavigate((index - 1 + items.length) % items.length)}
          aria-label="Previous image"
          className="hidden sm:flex shrink-0 text-cream-text/70 hover:text-lime transition-colors p-3"
        >
          <ChevronLeft size={32} />
        </button>

        <img
          src={resolveImage(item.image)}
          alt={item.caption}
          className="max-h-[70svh] md:max-h-[75vh] max-w-full object-contain frame-border"
        />

        <button
          type="button"
          onClick={() => onNavigate((index + 1) % items.length)}
          aria-label="Next image"
          className="hidden sm:flex shrink-0 text-cream-text/70 hover:text-lime transition-colors p-3"
        >
          <ChevronRight size={32} />
        </button>
      </div>

      <div className="shrink-0 px-6 py-6 text-center">
        <p className="font-display text-cream-text text-lg">{item.caption}</p>
        <div className="mt-4 flex sm:hidden items-center justify-center gap-8">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onNavigate((index - 1 + items.length) % items.length);
            }}
            aria-label="Previous image"
            className="text-cream-text/80 p-2"
          >
            <ChevronLeft size={26} />
          </button>
          <span className="font-mono-label text-xs text-mute">
            {index + 1} / {items.length}
          </span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onNavigate((index + 1) % items.length);
            }}
            aria-label="Next image"
            className="text-cream-text/80 p-2"
          >
            <ChevronRight size={26} />
          </button>
        </div>
      </div>
    </div>
  );
}
