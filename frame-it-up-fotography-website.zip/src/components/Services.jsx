import { services } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";

export default function Services() {
  const ref = useReveal();

  return (
    <section id="services" className="bg-ink py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <header className="max-w-2xl mb-14 md:mb-16">
          <p className="font-mono-label text-xs text-lime mb-4">
            What We Make
          </p>
          <h2 className="font-display text-4xl md:text-5xl leading-[1.1] text-cream-text text-balance">
            Photography and framing, under one roof.
          </h2>
        </header>

        <div
          ref={ref}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6"
        >
          {services.map((service, i) => (
            <article
              key={service.id}
              className="reveal group relative border border-ink-line bg-ink-soft overflow-hidden"
              data-reveal-delay={i * 70}
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={resolveImage(service.image)}
                  alt={service.title}
                  loading="lazy"
                  width={480}
                  height={600}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/10 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-500" />
                <span className="absolute top-3 left-3 spec-tag !text-[0.6rem] opacity-90">
                  {service.tag}
                </span>
              </div>
              <div className="p-5">
                <h3 className="font-display text-lg text-cream-text mb-1.5">
                  {service.title}
                </h3>
                <p className="text-sm text-mute leading-relaxed">
                  {service.description}
                </p>
              </div>
              <div className="absolute inset-x-0 bottom-0 h-0.5 bg-lime scale-x-0 group-hover:scale-x-100 origin-left transition-transform duration-500" />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
