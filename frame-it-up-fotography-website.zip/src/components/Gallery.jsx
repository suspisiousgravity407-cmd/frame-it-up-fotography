import { useState } from "react";
import { galleryItems } from "../data/siteData";
import { resolveImage } from "../utils/images";
import { useReveal } from "../hooks/useReveal";
import Lightbox from "./Lightbox";

const spanClass = {
  tall: "sm:row-span-2",
  wide: "sm:col-span-2",
  regular: "",
};

export default function Gallery() {
  const ref = useReveal();
  const [activeIndex, setActiveIndex] = useState(null);

  return (
    <section id="portfolio" className="bg-ink py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <header className="max-w-2xl mb-14 md:mb-16">
          <p className="font-mono-label text-xs text-lime mb-4">Portfolio</p>
          <h2 className="font-display text-4xl md:text-5xl leading-[1.1] text-cream-text text-balance">
            A gallery of frames, not just photographs.
          </h2>
          <p className="mt-4 text-mute text-base max-w-lg">
            Tap any piece to view it full-screen.
          </p>
        </header>

        <div
          ref={ref}
          className="grid grid-cols-2 sm:grid-cols-3 auto-rows-[180px] sm:auto-rows-[220px] md:auto-rows-[260px] gap-3 md:gap-4"
        >
          {galleryItems.map((item, i) => (
            <button
              type="button"
              key={item.id}
              onClick={() => setActiveIndex(i)}
              className={`reveal group relative overflow-hidden bg-ink-soft text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-lime ${spanClass[item.span]}`}
              data-reveal-delay={(i % 6) * 60}
              aria-label={`View ${item.caption}`}
            >
              <img
                src={resolveImage(item.image)}
                alt={item.caption}
                loading="lazy"
                width={600}
                height={750}
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />
              <div className="absolute inset-x-0 bottom-0 p-4 translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-400">
                <span className="spec-tag !text-[0.58rem] mb-1.5 !bg-transparent !border-lime/50">
                  {item.category}
                </span>
                <p className="text-cream-text text-sm font-body leading-snug mt-1">
                  {item.caption}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {activeIndex !== null && (
        <Lightbox
          items={galleryItems}
          index={activeIndex}
          onClose={() => setActiveIndex(null)}
          onNavigate={setActiveIndex}
        />
      )}
    </section>
  );
}
