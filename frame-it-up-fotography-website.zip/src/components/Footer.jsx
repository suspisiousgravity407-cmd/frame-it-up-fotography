import { Phone, MapPin } from "lucide-react";
import InstagramIcon from "./icons/InstagramIcon";
import { business, nav } from "../data/siteData";
import { resolveImage } from "../utils/images";

const logo = resolveImage("logo/logo-full.png");

export default function Footer() {
  const year = new Date().getFullYear();

  const handleNavClick = (e, href) => {
    e.preventDefault();
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-ink border-t border-ink-line pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-10 pb-12">
          <div className="col-span-2 md:col-span-1">
            <img src={logo} alt={`${business.name} logo`} className="h-12 w-auto mb-4 rounded-sm" />
            <p className="text-mute text-sm max-w-xs leading-relaxed">
              {business.subTagline}
            </p>
          </div>

          <div>
            <h4 className="font-mono-label text-xs text-lime mb-4">
              Navigate
            </h4>
            <ul className="space-y-2.5">
              {nav.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    onClick={(e) => handleNavClick(e, item.href)}
                    className="text-sm text-cream-text/75 hover:text-lime transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-mono-label text-xs text-lime mb-4">
              Contact
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href={business.phoneHref}
                  className="inline-flex items-center gap-2 text-sm text-cream-text/75 hover:text-lime transition-colors"
                >
                  <Phone size={14} /> {business.phone}
                </a>
              </li>
              <li className="inline-flex items-start gap-2 text-sm text-cream-text/75">
                <MapPin size={14} className="mt-0.5 shrink-0" />
                {business.location}
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono-label text-xs text-lime mb-4">Follow</h4>
            <a
              href={business.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm text-cream-text/75 hover:text-lime transition-colors"
            >
              <InstagramIcon size={16} />
              {business.instagramHandle}
            </a>
          </div>
        </div>

        <div className="pt-8 border-t border-ink-line flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-mute font-mono-label">
            © {year} {business.name}. All rights reserved.
          </p>
          <p className="text-xs text-mute/70">
            {business.locationShort} · Shipping all over India
          </p>
        </div>
      </div>
    </footer>
  );
}
