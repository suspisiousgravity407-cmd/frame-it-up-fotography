import { useEffect, useRef } from "react";

/**
 * Adds the `is-visible` class to an element (and, by CSS, its `.reveal`
 * children) once it scrolls into view. Respects prefers-reduced-motion via
 * the CSS rules in index.css (transitions collapse to instant there).
 */
export function useReveal(options = {}) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;

    const targets = el.classList.contains("reveal")
      ? [el]
      : Array.from(el.querySelectorAll(".reveal"));

    if (targets.length === 0) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            const target = entry.target;
            const delay = target.dataset.revealDelay || i * 80;
            setTimeout(() => target.classList.add("is-visible"), Number(delay));
            observer.unobserve(target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -40px 0px", ...options }
    );

    targets.forEach((t) => observer.observe(t));
    return () => observer.disconnect();
  }, [options]);

  return ref;
}
