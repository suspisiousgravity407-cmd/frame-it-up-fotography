// ============================================================================
// FRAME IT UP FOTOGRAPHY — SITE CONTENT
// Edit everything here. Business name, phone, location, Instagram, services,
// and gallery captions all live in this one file so you don't have to dig
// through component code to make a text change.
// ============================================================================

export const business = {
  name: "Frame It Up Fotography",
  shortName: "Frame It Up",
  tagline: "We Don't Just Capture Moments. We Frame Them.",
  subTagline:
    "Wedding & pre-wedding photography, custom collage frames and personalised keepsakes — made in Coimbatore, shipped all over India.",
  phone: "+91 82489 28404",
  phoneHref: "tel:+918248928404",
  whatsappHref: "https://wa.me/918248928404",
  location: "Coimbatore, Tamil Nadu, India",
  locationShort: "Coimbatore, Tamil Nadu",
  instagramHandle: "@frame_it_up_fotography",
  instagramUrl: "https://instagram.com/frame_it_up_fotography",
  mapsUrl: "https://www.google.com/maps/search/?api=1&query=Coimbatore+Tamil+Nadu+India",
  // Replace with a real inbox if/when you have one — leave blank to hide the mailto link.
  email: "",
};

export const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Contact", href: "#contact" },
];

// Services — mix of the photography side and the framing/gifting side.
// `tag` mimics the studio's own product-label handwriting style (seen on their
// keychain & money-bank photos) and doubles as the site's signature detail.
export const services = [
  {
    id: "wedding",
    title: "Wedding Photography",
    tag: "FULL DAY · CANDID",
    description:
      "Full wedding-day coverage — rituals, portraits and candid moments, shot to be framed, not just filed away.",
    image: "hero/wedding-couple.jpg",
  },
  {
    id: "pre-wedding",
    title: "Pre-Wedding Shoots",
    tag: "STORY SHOOT",
    description:
      "Location-based story shoots for couples — temples, streets and golden-hour light, planned around your story.",
    image: "hero/temple-top.jpg",
  },
  {
    id: "collage-frames",
    title: "Custom Collage Frames",
    tag: "BATCH · FAREWELL",
    description:
      "Farewell batches, class memories and group portraits, composed into one large keepsake frame.",
    image: "gallery/bcom-frame.jpg",
  },
  {
    id: "portrait-frames",
    title: "Premium Portrait Frames",
    tag: "PREMIUM FINISH",
    description:
      "Studio and event portraits printed and set in premium textured frames, ready to hang.",
    image: "gallery/bridal-frame.jpg",
  },
  {
    id: "money-banks",
    title: "Personalised Money Banks",
    tag: "WOODEN · CUSTOM",
    description:
      "Wooden money banks wrapped in your own photographs — a keepsake that's actually used every day.",
    image: "products/money-bank.jpg",
  },
  {
    id: "photo-pillows",
    title: "Photo Pillows & Cushions",
    tag: "16\" × 16\"",
    description:
      "Heart and square fur cushions printed with your photos, including sequin reveal-style cushions.",
    image: "products/photo-pillows.jpg",
  },
  {
    id: "photo-keychains",
    title: "Photo Keychains",
    tag: "METAL · MINI",
    description:
      "Compact metal keychains and photo lockets, custom-printed and finished by hand.",
    image: "products/photo-keychains.jpg",
  },
  {
    id: "mini-frames",
    title: "Mini & Devotional Frames",
    tag: "FROM ₹99",
    description:
      "Small-format frames for pooja rooms and desks, starting at ₹99.",
    image: "products/murugan-frame.jpg",
  },
];

// Portfolio / gallery grid — mixed sizes for the masonry layout.
export const galleryItems = [
  {
    id: "g1",
    image: "hero/wedding-couple.jpg",
    category: "Pre-Wedding",
    caption: "Temple story shoot, Coimbatore",
    span: "tall",
  },
  {
    id: "g2",
    image: "gallery/bcom-frame.jpg",
    category: "Collage Frame",
    caption: "B.Com Professional Accounting, farewell batch 2023–26",
    span: "wide",
  },
  {
    id: "g3",
    image: "gallery/bridal-frame.jpg",
    category: "Portrait Frame",
    caption: "Bridal portrait, premium textured frame",
    span: "tall",
  },
  {
    id: "g4",
    image: "gallery/sunday-frames.jpg",
    category: "Collage Frame",
    caption: "\"Memories of L-Block\" — English batch 2022–25",
    span: "regular",
  },
  {
    id: "g5",
    image: "products/combo-offer.jpg",
    category: "Combo",
    caption: "7-frame mega combo, weekend offer",
    span: "regular",
  },
  {
    id: "g6",
    image: "gallery/frames-pile.jpg",
    category: "Batch Order",
    caption: "Farewell 2026 batch — dispatched",
    span: "wide",
  },
  {
    id: "g7",
    image: "products/photo-pillows.jpg",
    category: "Photo Gifts",
    caption: "Fur cushions & sequin reveal pillows",
    span: "regular",
  },
  {
    id: "g8",
    image: "products/photo-keychains.jpg",
    category: "Photo Gifts",
    caption: "Custom metal photo keychains",
    span: "regular",
  },
  {
    id: "g9",
    image: "gallery/frames-wrapped.jpg",
    category: "Batch Order",
    caption: "Packed & ready — farewell frame batch",
    span: "tall",
  },
  {
    id: "g10",
    image: "products/murugan-frame.jpg",
    category: "Mini Frame",
    caption: "Mini Murugan devotional frame, ₹99",
    span: "regular",
  },
  {
    id: "g11",
    image: "products/money-bank.jpg",
    category: "Photo Gifts",
    caption: "Personalised wooden money bank",
    span: "wide",
  },
];

export const featuredWork = [
  {
    id: "f1",
    image: "gallery/bcom-frame.jpg",
    title: "B.Com Professional Accounting — Farewell 2023–26",
    description:
      "62 faces, one frame. Our most-requested format: a full graduating batch composed into a single large keepsake.",
  },
  {
    id: "f2",
    image: "hero/wedding-couple.jpg",
    title: "Temple Story Shoot",
    description:
      "A pre-wedding story told in the walk toward the mandapam — planned, shot and delivered as a complete narrative.",
  },
];

export const whyChooseUs = [
  {
    id: "w1",
    title: "Photography & Framing, One Studio",
    description:
      "We shoot the moment and we build the keepsake — no handing your photos off to a separate print shop.",
  },
  {
    id: "w2",
    title: "Built for Batch Orders",
    description:
      "From single portraits to farewell batches of 60+ students, dispatched and packed with individual care.",
  },
  {
    id: "w3",
    title: "Ships All Over India",
    description:
      "Every order is bubble-wrapped and boxed for transit, with tracked dispatch to any state in the country.",
  },
  {
    id: "w4",
    title: "Real Customer Feedback",
    description:
      "Our work is shared and reshared by the people who ordered it — see it firsthand on our Instagram.",
  },
];

// Static Instagram-style tiles (no API — these are real product photos).
export const instagramTiles = [
  "gallery/bridal-frame.jpg",
  "products/murugan-frame.jpg",
  "gallery/bcom-frame.jpg",
  "products/photo-pillows.jpg",
  "products/photo-keychains.jpg",
  "gallery/sunday-frames.jpg",
];
