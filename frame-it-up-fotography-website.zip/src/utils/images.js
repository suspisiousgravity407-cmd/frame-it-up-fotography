// Resolves the string paths used in siteData.js (e.g. "products/money-bank.jpg")
// to the actual bundled asset URL that Vite generates.
const modules = import.meta.glob("../assets/**/*.{jpg,jpeg,png}", {
  eager: true,
  import: "default",
});

const lookup = {};
for (const path in modules) {
  const key = path.replace("../assets/", "");
  lookup[key] = modules[path];
}

export function resolveImage(relativePath) {
  const found = lookup[relativePath];
  if (!found) {
    console.warn(`[resolveImage] No asset found for "${relativePath}"`);
    return "";
  }
  return found;
}
